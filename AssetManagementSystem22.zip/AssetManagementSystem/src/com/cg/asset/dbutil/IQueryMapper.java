package com.cg.asset.dbutil;

public interface IQueryMapper {

public static final	String INSERT_ASSET_INFO="INSERT INTO ASSET values(asset_seq.NEXTVAL,?,?,?,?)";
//public static final	String RETRIEVE_ASSET_BY_ID="SELECT * FROM ASSET where asset_id=?";
public static final	String ASSET_SEQ_CURR_ID="SELECT asset_seq.currval FROM dual";
public static final	String RETRIEVE_ALL_ASSET="SELECT * FROM ASSET";
public static final String DELETE ="DELETE FROM ASSET where assetid=?";
public static final String UPDATE_BY_NAME="update asset set assetname=? where assetid=?";
public static final String UPDATE_BY_DESC="update asset set assetdes=? where assetid=?";
public static final String UPDATE_BY_QUAN="update asset set quantity=? where assetid=?";
public static final String UPDATE_BY_STAT="update asset set status=? where assetid=?";
public static final String VIEW_ALLOC="select * from asset where status='allocated'";
public static final String VIEW_AVAIL="select * from asset where status='available'";

}
