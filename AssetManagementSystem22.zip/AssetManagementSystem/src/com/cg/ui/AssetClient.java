package com.cg.ui;
import com.cg.asset.bean.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import com.cg.asset.bean.*;
import com.cg.asset.exception.AssetException;
import com.cg.asset.service.*;

public class AssetClient {
	static IAssetService ias=null;
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String args[]) throws IOException
	{
		Asset asset=new Asset();
		
		int ch2;
		boolean res=login();
		if(res==true)
		{
			while(true)
			{
				System.out.println("---Asset Management---");
				System.out.println("1. Add Asset");
				System.out.println("2. Update Asset");
				System.out.println("3. Remove Asset");
				System.out.println("4. Retrieve Asset");
				System.out.println("5. Generate Report");
				System.out.println("6. Exit");
				System.out.println("Enter your choice: ");

				int ch=Integer.parseInt(br.readLine());

				switch(ch)
				{
				case 1:	System.out.println("Enter asset name: ");
				String assetName=br.readLine();
				System.out.println("Enter description");
				String desc=br.readLine();
				System.out.println("Enter asset quantity");
				int quantity=Integer.parseInt(br.readLine());
				System.out.println("Enter status: ");
				String status=br.readLine();

				asset.setAssetName(assetName);
				asset.setAssetDesc(desc);
				asset.setAssetQuantity(quantity);
				asset.setAssetStatus(status);

				try {
					int id=addAsset(asset);
					System.out.println("Asset added successfully!\n Asset ID: "+id);
				} catch (AssetException e) {

					System.out.println(e.getMessage());
				}

				break;

				case 2:	updateAsset();
				break;

				case 3: System.out.println("Enter asset id: ");
				int id=Integer.parseInt(br.readLine());
				try {
					deleteById(id);
				} catch (AssetException e) {
					System.err.println(e.getMessage());
				}
				break;

				case 4:
					break;

				case 5:
					System.out.println("1. View allocated assets");
					System.out.println("2. View available assets");
					System.out.println("Enter your choice: ");
					ch2=Integer.parseInt(br.readLine());
					switch(ch2)
					{
					case 1:
						break;

					case 2: 
						break;
					}
					break;

				case 6: System.exit(0);
				break;
				}
				System.out.println("");
			}
	}
		else
		{
			
			System.out.println("");
			login();
		}
	}		
	public static boolean login() throws IOException
	{
		System.out.println("Enter your user name: ");
		String uName=br.readLine();
		System.out.println("Enter password: ");
		String password=br.readLine();
		
		if(uName.equals("admin") && password.equals("admin"))
		{
			return true;
		}
		else
		{
			System.out.println("Credentials are wrong.");
			return false;
		}
		
	}
		
	public static int addAsset(Asset asset) throws AssetException
	{
		ias=new AssetServiceImpl();
		
		return ias.addAsset(asset);
		
	}
	
	public static int updateAssetName(String uname, int id) throws AssetException
	{
		ias=new AssetServiceImpl();
		return ias.updateAssetName(uname,id);
	}
	
	public static int updateAssetDesc(String udesc, int id) throws AssetException
	{
		ias=new AssetServiceImpl();
		return ias.updateAssetDesc(udesc,id);
	}
	
	public static int updateAssetQuan(int uquan, int id) throws AssetException
	{
		ias=new AssetServiceImpl();
		return ias.updateAssetQuan(uquan,id);
	}
	
	public static int updateAssetStat(String ustatus, int id) throws AssetException
	{
		ias=new AssetServiceImpl();
		return ias.updateAssetStat(ustatus,id);
	}
	
	public static int deleteById(int assetId) throws AssetException{
		
		ias=new AssetServiceImpl();
		return ias.deleteById(assetId);
	}
	
	public static ArrayList<Asset> viewAllocated()
	{
		ias=new AssetServiceImpl();
		return ias.viewAllocated();
	}
	
	public static ArrayList<Asset> viewAvailable()
	{
		ias=new AssetServiceImpl();
		return ias.viewAvailable();
	}
	
	public static void updateAsset() throws NumberFormatException, IOException
	{
	
		System.out.println("Enter Asset Id: ");
		int id=Integer.parseInt(br.readLine());
		System.out.println("");
		System.out.println("What do you want to update?");
		System.out.println("1. Name");
		System.out.println("2. Description");
		System.out.println("3. Quantity");
		System.out.println("4. Status");
		int ch3=Integer.parseInt(br.readLine());
		
		switch(ch3)
		{
			case 1: System.out.println("Enter name to be updated: ");
					String uname=br.readLine();
					//System.out.println(uname);
					try {
						int stat=updateAssetName(uname,id);
						if(stat>0)
						{
							System.out.println("Name updated successfully!!");
						}
						else
						{
							System.err.println("Name not updated");
							updateAsset();
						}
					} catch (AssetException e) {

						System.out.println(e.getMessage());
					}
					
				break;
				
			case 2:	System.out.println("Enter description to be updated: ");
			 		String udesc=br.readLine();
			 		try {
			 			int stat=updateAssetDesc(udesc,id);
			 			if(stat>0)
			 			{
			 				System.out.println("Description updated successfully!!");
			 			}
			 			else
			 			{
			 				System.err.println("Description not updated");
			 				updateAsset();
			 			}
			 		} catch (AssetException e) {

			 			System.out.println(e.getMessage());
			 		}
			 		
			 		break;
			
			case 3: System.out.println("Enter quantity to be updated: ");
					int uquan=Integer.parseInt(br.readLine());
					try {
						int stat=updateAssetQuan(uquan,id);
						if(stat>0)
						{
							System.out.println("Quantity updated successfully!!");
						}
						else
						{
							System.err.println("Quantity not updated");
							updateAsset();
						}
					} catch (AssetException e) {

						System.out.println(e.getMessage());
					}
					
				break;
			
			case 4: System.out.println("Enter status to be updated: ");
			 		String ustatus=br.readLine();
			 		try {
			 			int stat=updateAssetStat(ustatus,id);
			 			if(stat>0)
			 			{
			 				System.out.println("Status updated successfully!!");
			 			}
			 			else
			 			{
			 				System.err.println("Status not updated");
			 				updateAsset();
			 			}
			 		} catch (AssetException e) {

			 			System.out.println(e.getMessage());
			 		}
			 		
		 		break;
		}
	}
	
}
